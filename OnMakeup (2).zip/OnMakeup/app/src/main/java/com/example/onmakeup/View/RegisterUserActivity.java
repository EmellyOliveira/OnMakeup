package com.example.onmakeup.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.User;
import com.example.onmakeup.R;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class RegisterUserActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    private TextView  txtStatus, idUser;
    private EditText editTextFullName, editTextAge,   editTextEmail, editTextPassword;
    private Spinner comboU;
    public ImageView imageViewlogoImg2, imagemPerfil;
    public EditText editTextPhoneUser;
    private Button btnregisterUser,btnFecharUser, btnImagem;
    String[] status= {"Selecionar", "Cliente","Maquiador(a)"};
    final int REQUEST_CODE_GALERY= 999;
    User u = new User();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        //EditText
        editTextFullName = (EditText) findViewById(R.id.fullName);
        editTextAge = (EditText) findViewById(R.id.age);
        editTextPhoneUser = (EditText) findViewById(R.id.phoneUser);
        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.password);
        //..
        //imageView
        imagemPerfil = (ImageView) findViewById(R.id.imagePerfil);
        //Button
        btnregisterUser = (Button) findViewById(R.id.btnregisterUser);
        btnregisterUser.setOnClickListener(this);
        btnFecharUser = (Button) findViewById(R.id.btnFecharUser);
        btnFecharUser.setOnClickListener(this);
        btnImagem = (Button) findViewById(R.id.btnImagem);
        btnImagem.setOnClickListener(this);
        //..
        //Spinner
        comboU=(Spinner) findViewById(R.id.cbxStatusU);
        ArrayAdapter adp= new ArrayAdapter(this, android.R.layout.simple_spinner_item, android.R.id.text1,
                status);
        comboU.setAdapter(adp);

        comboU.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnImagem:
                ActivityCompat.requestPermissions(RegisterUserActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_GALERY );
                break;

            case R.id.btnregisterUser:
                String resposta="";
                CriarBanco con = new CriarBanco(this);

                u.setFullName(editTextFullName.getText().toString());
                u.setAge(editTextAge.getText().toString());
                u.setPhoneUser(editTextPhoneUser.getText().toString());
                u.setEmail(editTextEmail.getText().toString());
                u.setPassword(Integer.parseInt(editTextPassword.getText().toString()));
                u.setAvaliacao(0);
                u.setAtivo(1);
                try {
                    u.setImagem(imagemViewToByte(imagemPerfil));
                }
                catch (Exception err){
                    err.printStackTrace();

                }
                resposta = con.inserirCadastro(u);


               /* if (comboU.getSelectedItem().toString().equals("Maquiador(a)")){
                    startActivity(new Intent(this, RegisterServico.class ));
                }
                // if(comboU[0]){
                //    startActivity(new Intent(this, RegisterServico.class ));
                if (comboU.getSelectedItem().toString().equals("Cliente")){
                    startActivity(new Intent(this,Feed.class ));
                }
                //} if(comboU=="Cliente"){
                // startActivity(new Intent(this,Feed.class ));
               // }
               */ Toast.makeText(this, resposta, Toast.LENGTH_LONG).show();
                break;
            case R.id.btnFecharUser:
                finish();

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String item = (String)comboU.getItemAtPosition(i);
        u.setStatus(item);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull  String[] permissions, @NonNull  int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQUEST_CODE_GALERY){
            if(grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                Intent ab = new Intent(Intent.ACTION_PICK);
                ab.setType("image/*");
                startActivityForResult(ab, REQUEST_CODE_GALERY);
            }
            else{
                Toast.makeText(this, "Não possui permissão para acessar galeria", Toast.LENGTH_LONG).show();
            }
            return;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable  Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_CODE_GALERY && resultCode==RESULT_OK && data!=null){
            Uri uri = data.getData();
            try {
                InputStream inputstream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputstream);
                imagemPerfil.setImageBitmap(bitmap);
            }
            catch (FileNotFoundException err){
                err.printStackTrace();
            }
        }
    }
    public byte[] imagemViewToByte(ImageView img){
        Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
}