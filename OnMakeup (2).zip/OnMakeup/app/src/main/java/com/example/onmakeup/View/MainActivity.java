package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.User;
import com.example.onmakeup.R;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private EditText email, password;
    private Button signIn;
    private TextView register, forgotPassword;
    private Spinner combo;
    String[] status= {"Selecionar","Cliente","Maquiador(a)"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        combo=(Spinner) findViewById(R.id.cbxStatus);
        signIn = (Button) findViewById(R.id.signIn);
        forgotPassword = (TextView) findViewById(R.id.forgotPassword);
        register = (TextView) findViewById(R.id.register);

        ArrayAdapter adp= new ArrayAdapter(this, android.R.layout.simple_spinner_item, android.R.id.text1,
                status);
        combo.setAdapter(adp);


        combo.setOnItemSelectedListener(this);
        signIn.setOnClickListener(this);
        forgotPassword.setOnClickListener(this);
        register.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.signIn:
                CriarBanco con = new CriarBanco(this);
               int resp=con.validaLogin(email.getText().toString(),
                        Integer.parseInt(password.getText().toString()),
                        combo.getSelectedItem().toString());
                if(resp==0) {
                    Toast.makeText(this, "Usuário e senha não encontrados ou status não confere",
                            Toast.LENGTH_LONG).show();

                }
                else{
                    if(combo.getSelectedItem().toString().equals("Cliente")) {
                        startActivity(new Intent(this, FeedActivity.class));
                    }
                    if(combo.getSelectedItem().toString().equals("Maquiador(a)")){
                        Intent it = new Intent(this, RedefinirSenhaActivity.class);
                        it.putExtra("id_maquiador", resp);
                        startActivity(it);
                        startActivity(new Intent(this, RedefinirSenhaActivity.class));
                    }
                }

                //Toast.makeText(this, "Usuário e senha não encontrados", Toast.LENGTH_LONG).show();

                break;

            case R.id.register:
                startActivity(new Intent(this, RegisterUserActivity.class));
                // Toast.makeText(this, "Registro", Toast.LENGTH_LONG).show();
                break;

            case R.id.forgotPassword:
                startActivity(new Intent(this, RedefinirSenhaActivity.class));
                //Toast.makeText(this, "Esqueci", Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}