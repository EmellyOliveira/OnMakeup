package com.example.onmakeup.Model;

import java.io.Serializable;

public class User implements Serializable {

    public String fullName, email, status, phoneUser, age;
    public int  password, idUser, avaliacao, ativo;
    public byte[] imagem;

    public User(String fullName, String email, String status, String phoneUser, String age, int password, int idUser, int avaliacao, int ativo, byte[] imagem) {
        this.idUser = idUser;
        this.fullName = fullName;
        this.email = email;
        this.status = status;
        this.phoneUser = phoneUser;
        this.age = age;
        this.password = password;
        this.avaliacao = avaliacao;
        this.ativo = ativo;
        this.imagem = imagem;
    }

    public User() {

    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPhoneUser() {
        return phoneUser;
    }

    public void setPhoneUser(String phoneUser) {
        this.phoneUser = phoneUser;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public int getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }

    public int getAtivo() {
        return ativo;
    }

    public void setAtivo(int ativo) {
        this.ativo = ativo;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }

    @Override
    public String toString() {
        return "User{" +
                "fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", status='" + status + '\'' +
                ", phoneUser='" + phoneUser + '\'' +
                ", age='" + age + '\'' +
                ", password=" + password +
                ", idUser=" + idUser +
                ", avaliacao=" + avaliacao +
                ", ativo=" + ativo +
                ", imagem=" + imagem +
                '}';
    }
}
