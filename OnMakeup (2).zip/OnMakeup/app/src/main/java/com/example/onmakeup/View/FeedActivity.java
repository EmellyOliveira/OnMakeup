package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.onmakeup.R;

public class FeedActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView txtDireitos;
    private EditText txtFiltro;
    private Button btnFiltro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed);

        txtFiltro = (EditText)findViewById(R.id.TxtFiltro);

        btnFiltro = (Button)findViewById(R.id.BtnFiltro);
        btnFiltro.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

    }
}