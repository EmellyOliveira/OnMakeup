package br.edu.ifms.onmakup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterEmp extends AppCompatActivity implements View.OnClickListener {
    private TextView registerEmp;
    private EditText editTextFullNameEmp, editTextAgeEmp, editTextEmailEmp, editTextPasswordEmp;
    private ProgressBar progressBar3;
    public ImageView imageViewlogoImg3;
    public EditText editTextPhoneEmp;

    private FirebaseAuth mAuth;


    public RegisterEmp(EditText editTextPhoneEmp, ImageView imageViewlogoImg3) {
        this.editTextPhoneEmp = editTextPhoneEmp;
        this.imageViewlogoImg3 = imageViewlogoImg3;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_emp);
        mAuth = FirebaseAuth.getInstance();

        imageViewlogoImg3 = (ImageView) findViewById(R.id.logoimg3);
        imageViewlogoImg3.setOnClickListener(this);

        registerEmp = (Button) findViewById(R.id.registeremp);
        registerEmp.setOnClickListener(this);

        editTextFullNameEmp = (EditText) findViewById(R.id.fullNameEmp);
        editTextAgeEmp = (EditText) findViewById(R.id.ageEmp);
        editTextPhoneEmp = (EditText) findViewById(R.id.phoneEmp);
        editTextEmailEmp = (EditText) findViewById(R.id.emailEmp);
        editTextPasswordEmp = (EditText) findViewById(R.id.passwordEmp);

        progressBar3 = (ProgressBar) findViewById(R.id.progressBar3);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.logoimg3:
                startActivity(new Intent(this, MainActivity.class));
                break;
            // case R.id.banner:
            //startActivity(new Intent(this, MainActivity.class));
            //break;
            case R.id.registeremp:
                registerEmp();
                break;

        }
    }

    private void registerEmp() {
        String emailEmp = editTextEmailEmp.getText().toString().trim();
        String phoneEmp= editTextPhoneEmp.getText().toString().trim();
        String passwordEmp = editTextPasswordEmp.getText().toString().trim();
        String fullNameEmp = editTextFullNameEmp.getText().toString().trim();
        String ageEmp = editTextAgeEmp.getText().toString().trim();

        if(phoneEmp.isEmpty()){
            editTextPhoneEmp.setError("É necessário informar o telefone");
            editTextPhoneEmp.requestFocus();
            return;
        }

        if(fullNameEmp.isEmpty()){
            editTextFullNameEmp.setError("É necessário informar o nome");
            editTextFullNameEmp.requestFocus();
            return;
        }

        if(ageEmp.isEmpty()){
            editTextAgeEmp.setError("É necessário informar a idade");
            editTextAgeEmp.requestFocus();
            return;
        }

        if(emailEmp.isEmpty()){
            editTextEmailEmp.setError("É necessário informar o e-mail");
            editTextEmailEmp.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(emailEmp).matches()){
            editTextEmailEmp.setError("Por favor informe um e-mail válido");
            editTextEmailEmp.requestFocus();
            return;
        }

        if(passwordEmp.isEmpty()){
            editTextPasswordEmp.setError("É necessário informar uma senha");
            editTextPasswordEmp.requestFocus();
            return;
        }

        if(passwordEmp.length() < 6){
            editTextPasswordEmp.setError("informe no mínimo 6 caracteres");
            editTextPasswordEmp.requestFocus();
            return;
        }

        progressBar3.setVisibility(View.GONE);
        mAuth.createUserWithEmailAndPassword(emailEmp, passwordEmp).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {

            if(task.isSuccessful()){
                Emp emp = new Emp(fullNameEmp, ageEmp, emailEmp);

                FirebaseDatabase.getInstance().getReference("Users")
                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .setValue(emp).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task){

                        if(task.isSuccessful()){
                            Toast.makeText(RegisterEmp.this, "Cadastrado com sucesso!", Toast.LENGTH_LONG).show();
                            progressBar3.setVisibility(View.VISIBLE);

                            //redirect to layout
                        } else {
                            Toast.makeText(RegisterEmp.this, "Falhou tente novamente", Toast.LENGTH_LONG).show();
                            progressBar3.setVisibility(View.GONE);
                        }

                    }
                });
            } else {
                Toast.makeText(RegisterEmp.this, "Falha ao cadastrar", Toast.LENGTH_LONG).show();
                progressBar3.setVisibility(View.GONE);
            }

        }
    });
    }
}



