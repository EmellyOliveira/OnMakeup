package br.edu.ifms.onmakup;

public class Emp {
    public String fullNameEmp, ageEmp, emailEmp;


    public Emp() {

    }

    public Emp(String fullNameEmp, String age, String email){
        this.fullNameEmp = this.fullNameEmp;
        this.ageEmp = age;
        this.emailEmp = email;
    }
}
