package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.Agenda;
import com.example.onmakeup.R;

import java.util.ArrayList;
import java.util.List;

public class RegisterDiaActivity extends AppCompatActivity implements View.OnClickListener{
   CriarBanco con = new CriarBanco(this);
    List<Agenda> listAge = new ArrayList<Agenda>();
    Agenda ag = new Agenda();

    int idDia=0;
    private EditText lblCS, lblTS, lblCT, lblTT, lblCQ,
            lblTQ, lblCQui, lblTQui, lblCSex, lblTSex, lblCSab, lblTSab, lblCD, lblTD;
    private Switch btnS, btnT, btnQua, btnQui, btnSex, btnSab, btnD;
    private Button registerDia, pularetapa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_dia);
        //EditText
        //hora que começa o dia
        lblCS = (EditText) findViewById(R.id.lblCS);
        lblCT = (EditText) findViewById(R.id.lblCT);
        lblCQ = (EditText) findViewById(R.id.lblCQ);
        lblCQui = (EditText) findViewById(R.id.lblCQui);
        lblCSex = (EditText) findViewById(R.id.lblCSex);
        lblCSab = (EditText) findViewById(R.id.lblCSab);
        lblCD = (EditText) findViewById(R.id.lblCD);
        //...
        //hora que termina o dia
        lblTS = (EditText) findViewById(R.id.lblTS);
        lblTT = (EditText) findViewById(R.id.lblTT);
        lblTQ = (EditText) findViewById(R.id.lblTQ);
        lblTQui = (EditText) findViewById(R.id.lblTQui);
        lblTSex = (EditText) findViewById(R.id.lblTSex);
        lblTSab = (EditText) findViewById(R.id.lblTSab);
        lblTD = (EditText) findViewById(R.id.lblTD);
        //...
        Bundle age = getIntent().getExtras();
        idDia= age.getInt("passaId");
        //Button
        btnS = (Switch) findViewById(R.id.btnS);
        btnT = (Switch)findViewById(R.id.btnT);
        btnQua = (Switch)findViewById(R.id.btnQua);
        btnQui = (Switch)findViewById(R.id.btnQui);
        btnSex = (Switch)findViewById(R.id.btnSex);
        btnSab = (Switch)findViewById(R.id.btnSab);
        btnD = (Switch)findViewById(R.id.btnD);

        registerDia = (Button) findViewById(R.id.registerDia);
        registerDia.setOnClickListener(this);
        pularetapa = (Button) findViewById(R.id.btnFecharDia);
        pularetapa.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerDia:
                String r="";
                CriarBanco con = new CriarBanco(this);
                ag.setIdAgenda(listAge.get(0).getIdAgenda());
                ag.setId_mak(listAge.get(0).getId_mak());
                ag.setSemana(listAge.get(0).getSemana());
                ag.setHinicio(lblCS.getText().toString());
                ag.setHfim(lblTS.getText().toString());
                if(btnS.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(1).getIdAgenda());
                ag.setId_mak(listAge.get(1).getId_mak());
                ag.setSemana(listAge.get(1).getSemana());
                ag.setHinicio(lblCT.getText().toString());
                ag.setHfim(lblTT.getText().toString());
                if(btnT.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(2).getIdAgenda());
                ag.setId_mak(listAge.get(2).getId_mak());
                ag.setSemana(listAge.get(2).getSemana());
                ag.setHinicio(lblCQ.getText().toString());
                ag.setHfim(lblTQ.getText().toString());
                if(btnQua.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(3).getIdAgenda());
                ag.setId_mak(listAge.get(3).getId_mak());
                ag.setSemana(listAge.get(3).getSemana());
                ag.setHinicio(lblCQui.getText().toString());
                ag.setHfim(lblTQui.getText().toString());
                if(btnQui.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(4).getIdAgenda());
                ag.setId_mak(listAge.get(4).getId_mak());
                ag.setSemana(listAge.get(4).getSemana());
                ag.setHinicio(lblCSex.getText().toString());
                ag.setHfim(lblTSex.getText().toString());
                if(btnSex.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(5).getIdAgenda());
                ag.setId_mak(listAge.get(5).getId_mak());
                ag.setSemana(listAge.get(5).getSemana());
                ag.setHinicio(lblCSab.getText().toString());
                ag.setHfim(lblTSab.getText().toString());
                if(btnSab.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);

                ag.setIdAgenda(listAge.get(6).getIdAgenda());
                ag.setId_mak(listAge.get(6).getId_mak());
                ag.setSemana(listAge.get(6).getSemana());
                ag.setHinicio(lblCD.getText().toString());
                ag.setHfim(lblTD.getText().toString());
                if(btnD.isChecked()){
                    ag.setStatus(1);
                }
                else{
                    ag.setStatus(0);
                }
                r = con.alterarAgendaDia(ag);
                finish();
               // startActivity(new Intent(this, AgendaActivity.class));
               break;

            case R.id.btnFecharDia:
                startActivity(new Intent(this, AgendaActivity.class));

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        listAge=con.getAgendaByUser(idDia);
        lblCS.setText(listAge.get(0).getHinicio());
        lblTS.setText(listAge.get(0).getHfim());
        if(listAge.get(0).getStatus()==1){
            btnS.setChecked(true);
        }
        lblCT.setText(listAge.get(1).getHinicio());
        lblTT.setText(listAge.get(1).getHfim());
        if(listAge.get(1).getStatus()==1){
            btnT.setChecked(true);
        }
        lblCQ.setText(listAge.get(2).getHinicio());
        lblTQ.setText(listAge.get(2).getHfim());
        if(listAge.get(2).getStatus()==1){
            btnQua.setChecked(true);
        }
        lblCQui.setText(listAge.get(3).getHinicio());
        lblTQui.setText(listAge.get(3).getHfim());
        if(listAge.get(3).getStatus()==1){
            btnQui.setChecked(true);
        }
        lblCSex.setText(listAge.get(4).getHinicio());
        lblTSex.setText(listAge.get(4).getHfim());
        if(listAge.get(4).getStatus()==1){
            btnSex.setChecked(true);
        }
        lblCSab.setText(listAge.get(5).getHinicio());
        lblTSab.setText(listAge.get(5).getHfim());
        if(listAge.get(5).getStatus()==1){
            btnSab.setChecked(true);
        }

        lblCD.setText(listAge.get(6).getHinicio());
        lblTD.setText(listAge.get(6).getHfim());
        if(listAge.get(6).getStatus()==1){
            btnD.setChecked(true);
        }
    }
}