package com.example.onmakeup.Model;

import java.io.Serializable;

public class Servico implements Serializable {
    public int idServico;
    public String servicos, lblTempo;
    public Double valor;
    public int id_mak;


    public Servico(int idServico, String servicos, Double valor, String lblTempo, int id_mak ){
        this.idServico = idServico;
        this.servicos = servicos;
        this.lblTempo = lblTempo;
        this.valor = valor;
        this.id_mak = id_mak;

    }

    public Servico() {

    }


    public int getIdServico() {
        return idServico;
    }

    public void setIdServico(int idServico) {
        this.idServico = idServico;
    }

    public String getLblTempo() {
        return lblTempo;
    }

    public void setLblTempo(String lblTempo) {
        this.lblTempo = lblTempo;
    }

    public String getServicos() {
        return servicos;
    }

    public void setServicos(String servicos) {
        this.servicos = servicos;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public int getId_mak() {
        return id_mak;
    }

    public void setId_mak(int id_mak) {
        this.id_mak = id_mak;
    }

    @Override
    public String toString() {
        return "Servico{" +
                "idServico=" + idServico +
                ", servicos='" + servicos + '\'' +
                ", valor=" + valor +
                ", lblTempo=" + lblTempo +
                ", id_mak=" + id_mak +
                '}';
    }
}
