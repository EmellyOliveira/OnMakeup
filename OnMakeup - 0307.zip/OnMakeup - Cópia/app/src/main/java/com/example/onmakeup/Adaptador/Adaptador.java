package com.example.onmakeup.Adaptador;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.User;
import com.example.onmakeup.R;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder>{
    //CriarBanco con;

    List<User> lista;

    //AppCompatActivity parent;
    //Context context;
     public Adaptador(List<User> lista) {
     this.lista = lista;
    // this.parent = parent;
         //, AppCompatActivity parent
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //context = parent.getContext();
        //con= new CriarBanco(context);
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_modelo_recycler,
                parent, false);
        return new MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
         holder.nomeMF.setText(lista.get(position).getFullName());
         holder.telefoneMF.setText(lista.get(position).getPhoneUser());
       /* try{
            ByteArrayInputStream imagemStream = new ByteArrayInputStream(lista.get(position).getImagem());
            Bitmap bitmap = BitmapFactory.decodeStream(imagemStream);
            holder.imageView2.setImageBitmap(bitmap);
        }
        catch (Exception err){
        }*/

    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView nomeMF, telefoneMF;
        private ImageView imageView2;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nomeMF = itemView.findViewById(R.id.nomeMF);
            telefoneMF = itemView.findViewById(R.id.telefoneMF);
            //imageView2 = itemView.findViewById(R.id.imageView2);
        }
    }

}
