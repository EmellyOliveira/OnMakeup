package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;


import com.example.onmakeup.Adaptador.Adaptador;
import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.*;
import com.example.onmakeup.R;
import com.example.onmakeup.RecyclerView.RecyclerItemClickListener;

import java.util.ArrayList;
import java.util.List;

public class FeedActivity extends AppCompatActivity implements View.OnClickListener {
    CriarBanco con = new CriarBanco(this);
    private EditText txtFiltro;
    private Button btnFiltro;
    private ImageView imageConfigura;
    private RecyclerView lojas;
    List<User> maquiadores = new ArrayList<User>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed);
        txtFiltro = (EditText) findViewById(R.id.TxtFiltro);

        imageConfigura = (ImageView) findViewById(R.id.imageConfigurar);
        imageConfigura.setOnClickListener(this);
        btnFiltro = (Button) findViewById(R.id.BtnFiltro);
        btnFiltro.setOnClickListener(this);
        lojas = (RecyclerView) findViewById(R.id.Lojas);
    }

    @Override
    protected void onResume() {
        super.onResume();
        maquiadores = con.getMaquiadores();
        //Toast.makeText(this, ""+maquiadores.get(0).getFullName(),Toast.LENGTH_LONG).show();
        //adaptador
        Adaptador adp = new Adaptador(maquiadores);
        //recycler

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        lojas.setLayoutManager(layoutManager);
        lojas.setHasFixedSize(true);
        lojas.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
        lojas.setAdapter(adp);

        /*lojas.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), lojas, new RecyclerItemClickListener.OnItemClickListener() {

            @Override
            public void onItemClick(View view, int position) {

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        }));*/
    }


    @Override
    public void onClick(View v) {
            switch (v.getId()){
                case R.id.imageConfigurar:
                    startActivity(new Intent(this, RegisterDiaActivity.class)); //Classe de configurações
                    break;
                case R.id.BtnFiltro:
                    //Filtrar informações
                    break;

            }

    }

    }

