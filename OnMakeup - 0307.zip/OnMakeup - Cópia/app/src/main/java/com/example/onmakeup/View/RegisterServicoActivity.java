package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.Model.Servico;
import com.example.onmakeup.R;


public class RegisterServicoActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    Servico s = new Servico();
    int id=0;
    private EditText lblTempo, lblValor;
    private Button btnRegisterServico, btnFecharSer;
    private Spinner comboS;
    String[] servicos= {"Selecionar", "Maquiagem Clássica",
            "Maquiagem Colorida", "Maquiagem Neutra",
            "Maquiagem Passarela", "Maquiagem Smokey eye"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_servico);
        //EditText
        lblTempo = (EditText) findViewById(R.id.lblTempo);
        lblValor = (EditText) findViewById(R.id.lblValor);
        //..
        Bundle b = getIntent().getExtras();
        id= b.getInt("id_maquiador");
        //Button
        btnRegisterServico = (Button) findViewById(R.id.btnRegisterServico);
        btnRegisterServico.setOnClickListener(this);
        btnFecharSer = (Button) findViewById(R.id.btnFecharSer);
        btnFecharSer.setOnClickListener(this);
        //..
        //Spinner
        comboS=(Spinner) findViewById(R.id.cbxServico);
        //..
        //Array Adapter
        ArrayAdapter adp= new ArrayAdapter(this, android.R.layout.simple_spinner_item, android.R.id.text1, servicos);
        comboS.setAdapter(adp);
        comboS.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View v) {


        switch (v.getId()){
            case R.id.btnRegisterServico:
                String resposta="";
                CriarBanco con = new CriarBanco(this);
                s.setValor(Double.parseDouble(lblValor.getText().toString()));
                s.setLblTempo(lblTempo.getText().toString());
                s.setId_mak(id);
                resposta = con.inserirServico(s);
                Intent it1 = new Intent(this, RegisterDiaActivity.class);
                it1.putExtra("passaId", id);
                startActivity(it1);
                //Toast.makeText(this, "Serviço "+s.getServicos()+" valor"+ s.getValor() + " tempo"+ s.getLblTempo() +" id "
                        //        +s.getId_mak(),
                        //Toast.LENGTH_LONG).show();
                break;

            case R.id.btnFecharSer:
                Intent it2 = new Intent(this, RegisterDiaActivity.class);
                it2.putExtra("passaId", id);
                startActivity(it2);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String item = (String)comboS.getItemAtPosition(i);
        s.setServicos(item);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}