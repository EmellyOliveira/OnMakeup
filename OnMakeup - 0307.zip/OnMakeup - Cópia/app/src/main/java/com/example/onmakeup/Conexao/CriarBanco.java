package com.example.onmakeup.Conexao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.onmakeup.Model.Agenda;
import com.example.onmakeup.Model.Servico;
import com.example.onmakeup.Model.User;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;

public class CriarBanco extends SQLiteOpenHelper {

    private final static String nomebanco="db_makeup";
    private final static int versaobanco=5;
    public CriarBanco(@Nullable Context context){
        super(context, nomebanco, null, versaobanco);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Tabela Usuário
        String criartbuser= "CREATE TABLE tb_user(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nome TEXT,"+
                "dataNascimento TEXT,"+
                "telefone TEXT,"+
                "email TEXT,"+
                "senha INTEGER,"+
                "status TEXT, " +
                "avaliacao INTEGER, " +
                "ativo INTEGER, " +
                "imagem BLOB)";
        db.execSQL(criartbuser);
        //Tabela serviço
        String criartbservico= "CREATE TABLE tb_servico(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "servicos TEXT,"+
                "valor DOUBLE,"+
                "tempo TEXT, " +
                "id_mak INTEGER," +
                "FOREIGN KEY (id_mak) REFERENCES tb_user (id))";
        db.execSQL(criartbservico);

        //Tabela Agenda
        String criartbagenda= "CREATE TABLE tb_agenda(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "id_mak INTEGER,"+
                "semana TEXT,"+
                "hinicio TEXT, " +
                "hfim TEXT, " +
                "status INTEGER," + //dia disponível ou não
                "FOREIGN KEY (id_mak) REFERENCES tb_user (id))";
        db.execSQL(criartbagenda);

        //Tabela Marcação
        String criartbmarcacao= "CREATE TABLE tb_marcacao(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "id_mak INTEGER,"+
                "id_usu INTEGER,"+
                "id_serv INTEGER," +
                "semana TEXT,"+
                "hinicio INTEGER, " +
                "status INTEGER," + //aceitou ou não o cliente
                "FOREIGN KEY (id_mak) REFERENCES tb_user (id)," +
                "FOREIGN KEY (id_usu) REFERENCES tb_user (id)," +
                "FOREIGN KEY (id_serv) REFERENCES tb_servico (id))";
        db.execSQL(criartbmarcacao);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
            String usu = "DROP TABLE  tb_user";
            db.execSQL(usu);
            String ser = "DROP TABLE  tb_servico";
            db.execSQL(ser);
            String age = "DROP TABLE  tb_agenda";
            db.execSQL(age);
            String mar = "DROP TABLE  tb_marcacao";
            db.execSQL(mar);
            onCreate(db);

    }

    //Usuário..
    public String inserirCadastro(User user) {
        long result;

        SQLiteDatabase db = getWritableDatabase();
        //String sqlInsert= "insert into tb_seriado";
        ContentValues valores = new ContentValues();
        valores.put("nome", user.getFullName());
        valores.put("dataNascimento", user.getAge());
        valores.put("telefone", user.getPhoneUser());
        valores.put("email", user.getEmail());
        valores.put("senha", user.getPassword());
        valores.put("status", user.getStatus());
        valores.put("avaliacao", user.getAvaliacao());
        valores.put("ativo", user.getAtivo());
        valores.put("imagem", user.getImagem());

        result = db.insert("tb_user", null, valores);
        db.close();
        if (result == -1) {
            return "Erro ao cadastrar usuário no Banco de Dados";
        } else {
            return "Usuário cadastrado no Banco de Dados com sucesso";
        }
    }

    public int validaLogin(String email, int senha, String status)
    {
        int resp=0;
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_user where email='"+email+"' and senha="+senha+
                " and status='"+status+"' and ativo=1" ;
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToFirst()) {
            resp=rs.getInt(0);
        }
        db.close();
        return resp;
    }

    public List<User> getUsuarios()
    {
        List<User> usuarios = new ArrayList<User>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_user";
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToFirst()) {
            do {
                User u = new User();
                u.setIdUser(rs.getInt(0));
                u.setFullName(rs.getString(1));
                u.setAge(rs.getString(2));
                u.setPhoneUser(rs.getString(3));
                u.setEmail(rs.getString(4));
                u.setPassword(rs.getInt(5));
                u.setStatus(rs.getString(6));
                u.setAvaliacao(rs.getInt(7));
                u.setAtivo(rs.getInt(8));
                u.setImagem(rs.getBlob(9));
                usuarios.add(u);
            }
            while (rs.moveToNext());

        }
        db.close();
        return usuarios;
    }

    public List<User> getMaquiadores()
    {
        List<User> usuarios = new ArrayList<User>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_user where status='Maquiador(a)'";
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToFirst()) {
            do {
                User u = new User();
                u.setIdUser(rs.getInt(0));
                u.setFullName(rs.getString(1));
                u.setAge(rs.getString(2));
                u.setPhoneUser(rs.getString(3));
                u.setEmail(rs.getString(4));
                u.setPassword(rs.getInt(5));
                u.setStatus(rs.getString(6));
                u.setAvaliacao(rs.getInt(7));
                u.setAtivo(rs.getInt(8));
                u.setImagem(rs.getBlob(9));
                usuarios.add(u);
            }
            while (rs.moveToNext());

        }
        db.close();
        return usuarios;
    }

    public int recuperaIdLastUsuario()
    {
        int id=0;
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_user";
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToLast()) {
            id=rs.getInt(0);
        }
        db.close();
        return id;
    }


    //Serviço..

    public String inserirServico(Servico servico) {
        long result;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues valoresServico = new ContentValues();
        valoresServico.put("servicos", servico.getServicos());
        valoresServico.put("valor", servico.getValor());
        valoresServico.put("tempo", servico.getLblTempo());
        valoresServico.put("id_mak", servico.getId_mak());

        result = db.insert("tb_servico", null, valoresServico);
        db.close();
        if (result == -1) {
            return "Erro ao cadastrar serviço no Banco de Dados";
        } else {
            return "Serviço cadastrado no Banco de Dados com sucesso";
        }
    }

    public List<Servico> getServico()
    {
        List<Servico> servicos = new ArrayList<Servico>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_servico";
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToFirst()) {
            do {
                Servico s = new Servico();
                s.setIdServico(rs.getInt(0));
                s.setServicos(rs.getString(1));
                s.setLblTempo(rs.getString(2));
                s.setValor(rs.getDouble(3));
                s.setId_mak(rs.getInt(4));
                servicos.add(s);

            }
            while (rs.moveToNext());

        }
        db.close();
        return servicos;
    }

    //agenda


    public String inserirAgenda(Agenda agenda) {
        long result;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues valoresAgenda = new ContentValues();
        valoresAgenda.put("semana", agenda.getSemana());
        valoresAgenda.put("hinicio", agenda.getHinicio());
        valoresAgenda.put("hfim", agenda.getHfim());
        valoresAgenda.put("status", agenda.getStatus());
        valoresAgenda.put("id_mak", agenda.getId_mak());

        result = db.insert("tb_agenda", null, valoresAgenda);
        db.close();
        if (result == -1) {
            return "Erro ao cadastrar agenda no Banco de Dados";
        } else {
            return "Agenda cadastrada no Banco de Dados com sucesso";
        }
    }

    public String alterarAgendaDia(Agenda agenda){
        long result;

        SQLiteDatabase db = getWritableDatabase();
        String meuWhere="id="+agenda.getIdAgenda() ;
        ContentValues valoresDia = new ContentValues();
        valoresDia.put("id_mak", agenda.getId_mak());
        valoresDia.put("semana", agenda.getSemana());
        valoresDia.put("hinicio", agenda.getHinicio());
        valoresDia.put("hfim", agenda.getHfim());
        valoresDia.put("status", agenda.getStatus());


        result = db.update("tb_agenda",valoresDia, meuWhere, null);
        db.close();
        if(result == -1){
            return "Erro ao alterar agenda no Banco de Dados";
        }
        else{
            return "Agenda alterada no Banco de Dados com sucesso";
        }

    }

    public List<Agenda> getAgendaByUser(int idmak)
    {
        List<Agenda> agenda = new ArrayList<Agenda>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from tb_agenda where id_mak="+idmak;
        Cursor rs = db.rawQuery(sql, null);

        if(rs.moveToFirst()) {
            do {
                Agenda a = new Agenda();
                a.setIdAgenda(rs.getInt(0));
                a.setId_mak(rs.getInt(1));
                a.setSemana(rs.getString(2));
                a.setHinicio(rs.getString(3));
                a.setHfim(rs.getString(4));
                a.setStatus(rs.getInt(5));
                agenda.add(a);
            }
            while (rs.moveToNext());

        }
        db.close();
        return agenda;
    }

}
