package com.example.onmakeup.Model;

import java.io.Serializable;

public class Agenda implements Serializable {
    public int idAgenda, status;
    public String semana, hinicio, hfim;
    public int id_mak;

    public Agenda() {
    }

    public Agenda(int idAgenda, String hinicio, String hfim, int status, String semana, int id_mak) {
        this.idAgenda = idAgenda;
        this.hinicio = hinicio;
        this.hfim = hfim;
        this.status = status;
        this.semana = semana;
        this.id_mak = id_mak;
    }

    public int getIdAgenda() {
        return idAgenda;
    }

    public void setIdAgenda(int idAgenda) {
        this.idAgenda = idAgenda;
    }

    public String getHinicio() {
        return hinicio;
    }

    public void setHinicio(String hinicio) {
        this.hinicio = hinicio;
    }

    public String getHfim() {
        return hfim;
    }

    public void setHfim(String hfim) {
        this.hfim = hfim;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getSemana() {
        return semana;
    }

    public void setSemana(String semana) {
        this.semana = semana;
    }

    public int getId_mak() {
        return id_mak;
    }

    public void setId_mak(int id_mak) {
        this.id_mak = id_mak;
    }

    @Override
    public String toString() {
        return "Agenda{" +
                "idAgenda=" + idAgenda +
                ", hinicio=" + hinicio +
                ", hfim=" + hfim +
                ", status=" + status +
                ", semana='" + semana + '\'' +
                ", id_mak=" + id_mak +
                '}';
    }
}
