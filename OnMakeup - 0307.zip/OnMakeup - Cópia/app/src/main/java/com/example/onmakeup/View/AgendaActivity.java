package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.onmakeup.Conexao.CriarBanco;
import com.example.onmakeup.R;

public class AgendaActivity extends AppCompatActivity implements View.OnClickListener{
    CriarBanco con = new CriarBanco(this);
    private TextView txtDireitosMak;
    private EditText txtFiltroMak;
    private Button btnFiltroMak;
    private ImageView imageConfiguraMak;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);
        txtFiltroMak = (EditText) findViewById(R.id.TxtFiltroMak);

        imageConfiguraMak = (ImageView) findViewById(R.id.imageConfigurarMak);
        imageConfiguraMak.setOnClickListener(this);
        btnFiltroMak = (Button) findViewById(R.id.BtnFiltro);
        btnFiltroMak.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

    }
}