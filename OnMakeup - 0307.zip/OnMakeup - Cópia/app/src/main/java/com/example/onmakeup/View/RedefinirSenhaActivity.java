package com.example.onmakeup.View;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.onmakeup.R;

public class RedefinirSenhaActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView intro;
    private Button redefinir, cancelar;
    private EditText editTextEmailReset;
    public ImageView imageViewlogoImg4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redefinir_senha);

        editTextEmailReset = (EditText) findViewById(R.id.emailreset);

        redefinir = (Button) findViewById(R.id.redefinir);
        redefinir.setOnClickListener(this);
        cancelar = (Button) findViewById(R.id.cancelar);
        cancelar.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.redefinir:
                //redefinir();
                startActivity(new Intent(this, MainActivity.class));
                break;

            case R.id.cancelar:
                //redefinir();
                finish();

        }
    }
}